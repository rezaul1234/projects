function rnd(l,u){
  return Math.floor(Math.random()*(u-l) + l);
}

function collision(obj1, obj2){
  let x1 = obj1.object3D.position.x;
  let x2 = obj2.object3D.position.x;
  let y1 = obj1.object3D.position.y;
  let y2 = obj2.object3D.position.y;
  let z1 = obj1.object3D.position.z;
  let z2 = obj2.object3D.position.z;
  
  let distance = Math.sqrt((x2 - x1)**2 + (y2 - y1)**2 + (z2 - z1)**2);
  //console.log( r(x1) + "\t" + r(y1) + "\t" + r(z1) + "\t" + distance);
  return distance < 1;
}
let r = (n) => Math.round(n)
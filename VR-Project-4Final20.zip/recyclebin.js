class Bin{
  constructor(x,y,z){
    this.x = x;
    this.z = z;
    this.y = y;

    this.obj = document.createElement("a-entity");

    let l = document.createElement("a-box");
    l.setAttribute("position", {x:-2.5, y:1, z:-4});
    l.setAttribute("width", 1);
    l.setAttribute("height", 1);
    l.setAttribute("depth", .1);
    l.setAttribute("material", "src: recycle.PNG")
    l.setAttribute("color", "blue");
    this.obj.append(l);  

    let i = document.createElement("a-cylinder");
    i.setAttribute("position", {x:-2.5, y:1, z:-5});
    i.setAttribute("radius", 1);
    i.setAttribute("height", 2);
    i.setAttribute("color", "rgb(0,200,0)");
    this.obj.append(i);

    this.obj.setAttribute("static-body", "");
    this.obj.setAttribute("position", {x:this.x, y:this.y, z:this.z});
    scene.append(this.obj)
  }
  changeRotation(i,j,k){
    this.i = i;
    this.j = j;
    this.k = k;
    this.obj.setAttribute("rotation", {x:this.i, y:this.j, z:this.k});

  }
}      

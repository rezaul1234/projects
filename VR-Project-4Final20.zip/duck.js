class Duck{
  constructor(x,y,z, speed){
    this.x = x;
    this.z = z;
    this.y = y;
    this.speed = speed;
    this.flag = false;

    this.obj = document.createElement("a-entity");
    let qk = loadSound("quack.mp3");

    let i = document.createElement("a-sphere");
    i.setAttribute("position", {x:3, y:1, z:-2});
    i.setAttribute("rotation", {x:0, y:.5, z:180});
    i.setAttribute("radius", 1);
    i.setAttribute("color", "yellow");
    i.setAttribute("theta-length", 90);
    this.obj.append(i);

    let l = document.createElement("a-sphere");
    l.setAttribute("position", {x:2.5, y:1.8, z:-2});
    l.setAttribute("radius", .5);
    l.setAttribute("color", "green");
    this.obj.append(l);

    let j = document.createElement("a-box");
    j.setAttribute("position", {x:2.5, y:1, z:-2});
    j.setAttribute("height", 1);
    j.setAttribute("width", .5);
    j.setAttribute("depth", .5);
    j.setAttribute("color", "rgb(0, 200, 0)");
    this.obj.append(j);

    let k = document.createElement("a-cone");
    k.setAttribute("position", {x:1.8, y:1.8, z:-2});
    k.setAttribute("rotation", {x:0, y:0, z:90});
    k.setAttribute("radius-top", .01);
    k.setAttribute("radius-bottom", .1);
    k.setAttribute("height", 0.5);
    k.setAttribute("color", "green");
    this.obj.append(k);

    let q = document.createElement("a-sphere");
    q.setAttribute("position", {x:2.1, y:2, z:-2.2});
    q.setAttribute("radius", .05);
    q.setAttribute("color", "black");
    this.obj.append(q);

    let t = document.createElement("a-sphere");
    t.setAttribute("position", {x:2.1, y:2, z:-1.8});
    t.setAttribute("radius", .05);
    t.setAttribute("color", "black");
    this.obj.append(t);

    this.obj.addEventListener("click", ()=>{
      this.flag = true;
      playSound(qk)
    })

    this.obj.setAttribute("position", {x:this.x, y:this.y, z:this.z});
    scene.append(this.obj)
  }
  move(){
    if(this.flag){
      this.x -= this.speed;
      if(this.x <= -70 || this.x > -30){
        this.obj.setAttribute("rotation", {x:0, y:180, z:0});
        this.speed = -this.speed;
      }
      if(this.speed < 0){
        this.obj.setAttribute("rotation", {x:0, y:180, z:0});
      }else{
        this.obj.setAttribute("rotation", {x:0, y:0, z:0});
      }
      this.obj.setAttribute("position", {x:this.x, y:this.y, z:this.z});
    }
  }
}
    
    
  
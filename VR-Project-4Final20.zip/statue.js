class Statue{
  constructor(x,y,z,w){
    this.x = x;
    this.z = z;
    this.y = y;
    this.w = w;

    this.obj = document.createElement("a-entity");


    let i = document.createElement("a-sphere");
    i.setAttribute("position", {x:0, y:7, z:-5});
    i.setAttribute("radius", 1);
    i.setAttribute("material", "src:statue.PNG");
    this.obj.append(i);

    let j = document.createElement("a-sphere");
    j.setAttribute("position", {x:.5, y:7, z:-4.2});
    j.setAttribute("radius", .1);
    j.setAttribute("color", "black");
    this.obj.append(j);

    let o = document.createElement("a-sphere");
    o.setAttribute("position", {x:-.5, y:7, z:-4.2});
    o.setAttribute("radius", .1);
    o.setAttribute("color", "black");
    this.obj.append(o);

    let k = document.createElement("a-cone");
    k.setAttribute("position", {x:0, y:5, z:-5});
    k.setAttribute("radius-bottom", 2);
    k.setAttribute("radius-top", .5);
    k.setAttribute("height", 3);
    k.setAttribute("material", "src:statue.PNG");
    this.obj.append(k);

    let p = document.createElement("a-cylinder");
    p.setAttribute("position", {x:1, y:2, z:-5});
    p.setAttribute("radius", .3);
    p.setAttribute("height", 4);
    p.setAttribute("material", "src:statue.PNG");
    this.obj.append(p);

    let q = document.createElement("a-cylinder");
    q.setAttribute("position", {x:-1, y:2, z:-5});
    q.setAttribute("radius", .3);
    q.setAttribute("height", 4);
    q.setAttribute("material", "src:statue.PNG");
    this.obj.append(q);

    let l = document.createElement("a-torus");
    l.setAttribute("position", {x:.5, y:3.5, z:-5});
    l.setAttribute("rotation", {x:0, y:180, z:90});
    l.setAttribute("arc", 100);
    l.setAttribute("radius", 2);
    l.setAttribute("radius-tubular", .1);
    l.setAttribute("material", "src:statue.PNG");
    this.obj.append(l);

    let b = document.createElement("a-torus");
    b.setAttribute("position", {x:0, y:7.5, z:-4.1});
    b.setAttribute("rotation", {x:0, y:180, z:-110});
    b.setAttribute("arc", 40);
    b.setAttribute("radius", 1);
    b.setAttribute("radius-tubular", .01);
    b.setAttribute("color", "blue");
    this.obj.append(b);

    let c = document.createElement("a-torus");
    c.setAttribute("position", {x:0, y:8, z:-5});
    c.setAttribute("rotation", {x:0, y:180, z:-80});
    c.setAttribute("arc", 90);
    c.setAttribute("radius", 2.5);
    c.setAttribute("radius-tubular", .1);
    c.setAttribute("material", "src:statue.PNG");
    this.obj.append(c);

    let m = document.createElement("a-cylinder");
    m.setAttribute("position", {x:-2.5, y:9, z:-5});
    m.setAttribute("radius", .2);
    m.setAttribute("height", 1.5);
    m.setAttribute("color", "#FFC65D");
    this.obj.append(m);

    let n = document.createElement("a-cylinder");
    n.setAttribute("position", {x:-2.5, y:10, z:-5});
    n.setAttribute("radius", .6);
    n.setAttribute("height", .2);
    n.setAttribute("color", "#FFC65D");
    this.obj.append(n);

    let u = document.createElement("a-sphere");
    u.setAttribute("position", {x:-2.5, y:10.5, z:-5});
    u.setAttribute("radius", .5);
    u.setAttribute("color", "yellow");
    this.obj.append(u);

    let v = document.createElement("a-cone");
    v.setAttribute("position", {x:-2.5, y:11, z:-5});
    v.setAttribute("radius-bottom", .5);
    v.setAttribute("radius-top", .01);
    v.setAttribute("height", 1.5);
    v.setAttribute("color", "yellow");
    this.obj.append(v);


    this.obj.setAttribute("position", {x:this.x, y:this.y, z:this.z});
    this.obj.setAttribute("rotation", {x:0, y:this.w, z:0});
    scene.append(this.obj)
  }
  rotate(){
    this.w += 5;
    if(this.w == 360){
      this.w = 0;
    }
    this.obj.setAttribute("rotation", {x:0, y:this.w, z:0});
  }
}

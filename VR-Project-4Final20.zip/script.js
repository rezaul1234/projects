let scene, a = 0, fish, z = -30, dz = 0.1, tree, l, duck, statue, fountain, fountain2, p1, p2, p3, p4, basketball, camera, basket2, board, basket, board2, k, c, dc=0.3, dk = 0.5, angle, msg, t = 0, msg2, t2 = 0;
let fiish = [];
let fish2 = [];
let ducck = [];
let door, doorop, b = 1;
let rimhit, score, fail, quack, flap, wdrop;

window.onload = function(){
  scene = document.querySelector("a-scene");
  camera = document.getElementById("camera");
  p1 = document.getElementById("p1");
  p2 = document.getElementById("p2");
  p3 = document.getElementById("p3");
  p4 = document.getElementById("p4");
  basketball = document.getElementById("basketball");
  basket = document.getElementById("basket");
  board2 = document.getElementById("board2");
  basket2 = document.getElementById("basket2");
  board = document.getElementById("board");
  c = camera.object3D.position.y;
  k = camera.object3D.position.z;
  angle = camera.object3D.rotation.y + Math.PI;

  basketball.addEventListener("click", function(){
    basketball.flag = true
    console.log("hi")
  })

  basket2.addEventListener("click", function(){
    basket2.flag = true
    console.log("hi")
  })

  basket.addEventListener("click", function(){
    basket.flag = true
    console.log("hi")
  })
  
  msg = document.getElementById("msg");
  msg.setAttribute("value","");
  
  msg2 = document.getElementById("msg2");
  msg2.setAttribute("value",""); 
  
  door = document.getElementById("door");
  doorop = document.getElementById("doorop");
  doorop.addEventListener("click", function(){
    doorop.flag = true; 
  })

  
  p1.addEventListener("mouseenter", function(){
    p1.flag = true
  })
  p1.addEventListener("mouseleave", function(){
    p1.flag = false
  })

  p2.addEventListener("mouseenter", function(){
    p2.flag = true
  })
  p2.addEventListener("mouseleave", function(){
    p2.flag = false
  })
  p3.addEventListener("mouseenter", function(){
    p3.flag = true
  })
  p3.addEventListener("mouseleave", function(){
    p3.flag = false
  })

  p4.addEventListener("mouseenter", function(){
    p4.flag = true
  })
  p4.addEventListener("mouseleave", function(){
    p4.flag = false
  })

  let w;
  for(var o = 55; o<=100; o+=10){
    for(var p = 20; p<=90; p+=10){
      w = new Tree(o, -.1, p);
    }
  }

  let ww;
  for(var o = 10; o<=40; o+=10){
    for(var p = 65; p<=90; p+=10){
      ww = new Tree(o, -.1, p);
    }
  }

  

  statue = new Statue(28,.5,-48, 0);

//Fish
  for(let o = -50; o<=-47; o+=2){
    for(let p = -50; p<=-47; p+=2){
      let speed = rnd(1,5)/10;
      let f = new Fish(o, .5, p, speed);
      fiish.push(f);
    }
  }

  for(let o = -35; o<=-32; o+=2){
    for(let p = -45; p<=-42; p+=2){
      let speed = rnd(1,5)/10;
      let f = new Fish(o, 0.5, p, speed);
      fish2.push(f);
    }
  }


  quack = loadSound("quack.mp3")
  
//Ducks
  for(let o = -50; o<=-47; o+=2){
    for(let p = -35; p<=-32; p+=2){
      let speed = rnd(1,5)/10;
      let f = new Duck(o, 0, p, speed);
      ducck.push(f);
    }
  }
  
  //Lamps
  let l1 = new Lamp(6,0,-5);
  l1.changeRotation(0,180,0)
  let l2 = new Lamp(-40,0,-12);
  let l3 = new Lamp(-70,0,-4);
  l3.changeRotation(0,180,0)
  let l4 = new Lamp(-1,0,-55);
  l4.changeRotation(0,-90,0)
  let l5= new Lamp(70,0,-12);

  //Recycle Bins
  let bin1 = new Bin(-8,0,0);
  bin1.changeRotation(0,-110,0)
  let bin2 = new Bin(-6,0,-80);
  bin2.changeRotation(0,90,0)
  let bin3 = new Bin(-90,0,-6);
  bin3.changeRotation(0,180,0);
  let bin4 = new Bin(90,0,-12);
  bin4.changeRotation(0,-40,0);

  //Benches
  let b1 = new Bench(0,.5 ,-5);
  let b2 = new Bench(-10,0.5, -5);
  let b3 = new Bench(-25,0.5,55);
  b3.changeRotation(0,80,0);
  let b4 = new Bench(55,.5,-80);
  b4.changeRotation(0,-80,0);
  let b5 = new Bench(25,.5,-96);
  b5.changeRotation(0,-45,0)
  let b6 = new Bench(-5,.5,-55);
  b6.changeRotation(0,45,0);
  let b7 = new Bench(5,.5,-20);
  b7.changeRotation(0, 90, 0)
  let b8 = new Bench(-100,.5,40);
  b8.changeRotation(0, 90, 0)
  let b9 = new Bench(-100,.5,55);
  b9.changeRotation(0, 90, 0)
  let b10 = new Bench(-60,.5,80);
  let b11 = new Bench(-50,.5,80);
  let b12 = new Bench(-20,.5,75);
  b12.changeRotation(0, 90, 0)
  let b13 = new Bench(-20,.5,90);
  b13.changeRotation(0, 90, 0);
  let b14 = new Bench(-50,.5,-100);
  let b15 = new Bench(-65,.5,-105);
  let b16 = new Bench(-100,.5,-80);
  b16.changeRotation(0,45,0);
  let b17 = new Bench(-105,.5,-75);
  b17.changeRotation(0,45,0);
  let b18 = new Bench(-98,.5,-10);
  b18.changeRotation(0, 90, 0)



  fountain = new Water(90,1,-82.1);
  fountain2 = new Water(-90,1,88);

    
  rimhit =loadSound("rimhit.mp3");
  score = loadSound("score.mp3");
  fail = loadSound("fail.mp3");
  wdrop = loadSound("wdrop.mp3");

  loop();

}


function loop(){

  if(doorop.flag){
    console.log("hi");
    b-=.5
    door.object3D.rotation.y +=-10
    door.setAttribute("opacity", `${b}`);
    doorop.flag =false
  }
  
  a += 1
  for(let fish of fiish){
    fish.move();
  }

  for(let fissh of fish2){
    fissh.move2();
  }

  for(let duck of ducck){
    duck.move();
    //playSound(quack);
  }

  if(p1.flag){
    fountain.move();
  }

  if(p2.flag){
    fountain.move2(-1.8);
  }

  if(p3.flag){
    fountain2.move();
  }

  if(p4.flag){
    fountain2.move2(1.8);
  }

  if(basketball.flag){
    basketball.object3D.position.x = camera.object3D.position.x;
    basketball.object3D.position.y = 1;
    basketball.object3D.position.z = camera.object3D.position.z;
    basketball.flag = false;
    console.log("2")
  }


  if(collision(basketball,board2)){   
    console.log("helloworld");
    t++;
    playSound(rimhit);
    playSound(score);
    basketball.object3D.position.x = camera.object3D.position.x;
    basketball.object3D.position.y = 1;
    basketball.object3D.position.z = camera.object3D.position.z;
    basket.flag = false;
  }

  msg2.setAttribute("value", `${t}`)

  
  if(basket.flag){
    k += dk
    c += dc;
    basketball.object3D.position.z += dk;
    basketball.object3D.position.y += dc;
    basketball.object3D.rotation.y += Math.PI
    
    if(basketball.object3D.position.z > board2.object3D.position.z){
    basketball.object3D.position.x = camera.object3D.position.x;
    basketball.object3D.position.y = 1;
    basketball.object3D.position.z = camera.object3D.position.z;
    basket.flag = false;
      playSound(fail);
    }
  }

  

  if(collision(basketball,board)){   
    console.log("helloworld");
    t2++
    playSound(rimhit);
    playSound(score);
    basketball.object3D.position.x = camera.object3D.position.x;
    basketball.object3D.position.y = 1;
    basketball.object3D.position.z = camera.object3D.position.z;
    basket2.flag = false;
  }
  msg.setAttribute("value", `${t2}`);

  if(basket2.flag){
    k += dk
    c += dc;
    basketball.object3D.position.z -= dk;
    basketball.object3D.position.y += dc;
    basketball.object3D.rotation.y += Math.PI

    if(basketball.object3D.position.z < board.object3D.position.z){
    basketball.object3D.position.x = camera.object3D.position.x;
    basketball.object3D.position.y = 1;
    basketball.object3D.position.z = camera.object3D.position.z;
    basket2.flag = false;
    playSound(fail)
    }
  }


  statue.rotate();
  
  setTimeout(loop, 100);
}


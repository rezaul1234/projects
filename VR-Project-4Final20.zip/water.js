class Water{
    constructor(x,y,z){
    this.x = x;
    this.z = z;
    this.y = y;
    this.w = -.1;


    this.obj = document.createElement("a-entity");
    let wdrop = loadSound("wdrop.mp3");


    let i = document.createElement("a-sphere");
    i.setAttribute("position", {x:0, y:1.92, z:-3});
    i.setAttribute("radius", 0.06);
    i.setAttribute("color", "silver");
    this.obj.append(i);

    let j = document.createElement("a-cone");
    j.setAttribute("position", {x:0, y:2, z:-3});
    j.setAttribute("radius-bottom", 0.05);
    j.setAttribute("radius-top", 0.01);
    j.setAttribute("color", "silver");
    j.setAttribute("height", .1)
    this.obj.append(j);

    this.obj.setAttribute("position", {x:this.x, y:this.y, z:this.z});
    scene.append(this.obj) 
  }
  move(){
    this.y += -.3;
    if(this.y < -1){
      this.y = 1;
      playSound(wdrop)
    }
    this.obj.setAttribute("position", {x:this.x, y:this.y, z:this.z});
  }
  move2(o){
    this.o = o;
    this.w += -.1;
    if(this.w < -.7){
      this.w = -.2;
      playSound(wdrop)
    }
    this.obj.setAttribute("position", {x:this.x, y:this.w, z:this.z-this.o});
  }
}
class Tree{
  constructor(x,y,z){
    this.x = x;
    this.z = z;
    this.y = y;

    this.obj = document.createElement("a-entity");


    let i = document.createElement("a-cylinder");
    i.setAttribute("position", {x:-5, y:.75, z:0});
    i.setAttribute("radius", .8);
    i.setAttribute("height", 7);
    i.setAttribute("color", "brown");
    this.obj.append(i);

    let j = document.createElement("a-torus");
    j.setAttribute("position", {x:-5, y:6, z:-0.1});
    j.setAttribute("rotation", {x:180, y:180, z:90})
    j.setAttribute("arc", 100);
    j.setAttribute("radius", 3);
    j.setAttribute("color", "green");
    j.setAttribute("radius-tubular", .3);
    this.obj.append(j);

    let o = document.createElement("a-torus");
    o.setAttribute("position", {x:-4.5, y:6, z:-0.1});
    o.setAttribute("rotation", {x:-180, y:-180, z:0})
    o.setAttribute("arc", 70);
    o.setAttribute("radius", 3);
    o.setAttribute("color", "green");
    o.setAttribute("radius-tubular", .3);
    this.obj.append(o);

    let k = document.createElement("a-box");
    k.setAttribute("position", {x:-4.8, y:8.5, z:0});
    k.setAttribute("width", 4);
    k.setAttribute("height", 8);
    k.setAttribute("depth", 3);
    k.setAttribute("material", "src: tree.PNG");
    k.setAttribute("color", "green");
    this.obj.append(k);

    let p = document.createElement("a-box");
    p.setAttribute("position", {x:-2.5, y:8, z:0});
    p.setAttribute("width", 2);
    p.setAttribute("height", 3);
    p.setAttribute("depth", 2);
    p.setAttribute("material", "src: tree.PNG");
    p.setAttribute("color", "green");
    this.obj.append(p);

    let l = document.createElement("a-box");
    l.setAttribute("position", {x:-7, y:7.5, z:0});
    l.setAttribute("width", 2);
    l.setAttribute("height", 3);
    l.setAttribute("depth", 2);
    l.setAttribute("material", "src: tree.PNG");
    l.setAttribute("color", "green");
    this.obj.append(l);    

    this.obj.setAttribute("static-body", "");
    this.obj.setAttribute("position", {x:this.x, y:this.y, z:this.z});
    scene.append(this.obj)
  }
}

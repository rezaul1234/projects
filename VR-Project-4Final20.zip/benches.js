class Bench{
  constructor(x,y,z){
    this.x = x;
    this.z = z;
    this.y = y;


    this.obj = document.createElement("a-entity");

    let k = document.createElement("a-box");
    k.setAttribute("position", {x:25, y:1.7, z:7});
    k.setAttribute("rotation", {x:90, y:0, z:0});
    k.setAttribute("width", 6);
    k.setAttribute("height", 5);
    k.setAttribute("depth", .5);
    k.setAttribute("material", "src: wood.jpg");
    k.setAttribute("color", "#4CC3D9");
    this.obj.append(k);

    let l = document.createElement("a-box");
    l.setAttribute("position", {x:23, y:.5, z:6.5});
    l.setAttribute("width", 2);
    l.setAttribute("height", 2);
    l.setAttribute("depth", 2);
    l.setAttribute("material", "src: woood.jpg");
    l.setAttribute("color", "green");
    this.obj.append(l);    

    let p = document.createElement("a-box");
    p.setAttribute("position", {x:27, y:.5, z:6.5});
    p.setAttribute("rotation", {x:0, y:0, z:0});
    p.setAttribute("width", 2);
    p.setAttribute("height", 2);
    p.setAttribute("depth", 2);
    p.setAttribute("material", "src: woood.jpg");
    p.setAttribute("color", "green");
    this.obj.append(p);


    this.obj.setAttribute("static-body", ""); 
    this.obj.setAttribute("position", {x:this.x, y:this.y, z:this.z});
    scene.append(this.obj)
  }
  
  changeRotation(i,j,k){
    this.i = i;
    this.j = j;
    this.k = k;
    this.obj.setAttribute("rotation", {x:this.i, y:this.j, z:this.k});

  }
}    
      
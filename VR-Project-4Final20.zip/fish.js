class Fish{
  constructor(x,y,z, speed){
    this.x = x;
    this.z = z;
    this.y = y;
    this.speed = speed;
    this.flag = false;

    this.obj = document.createElement("a-entity");
    let flap = loadSound("flap.mp3")
    
    let i = document.createElement("a-sphere");
    i.setAttribute("position", {x:0, y:.5, z:0});
    i.setAttribute("radius", .5);
    i.setAttribute("color", "rgb(0, 0, 200)");
    this.obj.append(i);

    let j = document.createElement("a-cone");
    j.setAttribute("position", {x:.5, y:.5, z:0});
    j.setAttribute("rotation", {x:-90, y:90, z:0})
    j.setAttribute("radius-bottom", .5);
    j.setAttribute("radius-top", .01);
    j.setAttribute("color", "rgb(0, 200, 0)");
    this.obj.append(j);

    let k = document.createElement("a-sphere");
    k.setAttribute("position", {x:-.3, y:.5, z:.3});
    k.setAttribute("radius", .1);
    k.setAttribute("color", "black");
    this.obj.append(k);

    let l = document.createElement("a-sphere");
    l.setAttribute("position", {x:-.3, y:.5, z:-.3});
    l.setAttribute("radius", .1);
    l.setAttribute("color", "black");
    this.obj.append(l);    

    this.obj.addEventListener("click", ()=>{
      this.flag = true;
      playSound(flap);
    })


    this.obj.setAttribute("position", {x:this.x, y:this.y, z:this.z});
    scene.append(this.obj)
  }

  move(){
    if(this.flag){
      this.x -= this.speed;
      if(this.x <= -70 || this.x > -40){
        this.speed = -this.speed;
      }
      if(this.speed < 0){
        this.obj.setAttribute("rotation", {x:0, y:180, z:0});
      }else{
        this.obj.setAttribute("rotation", {x:0, y:0, z:0});
      }
      this.obj.setAttribute("position", {x:this.x, y:this.y, z:this.z});
    }
  }


  move2(){
    if(this.flag){
      this.z -= this.speed;
      if(this.z <= -70 || this.z > -40){
        this.speed = -this.speed;
      }
      if(this.speed < 0){
        this.obj.setAttribute("rotation", {x:0, y:90, z:0});
      }else{
        this.obj.setAttribute("rotation", {x:0, y:-90, z:0});
      }
      this.obj.setAttribute("position", {x:this.x, y:this.y, z:this.z});
    }
  }
}
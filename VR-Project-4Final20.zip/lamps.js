class Lamp{
  constructor(x,y,z){
    this.x = x;
    this.z = z;
    this.y = y;

    this.obj = document.createElement("a-entity");
    let lon = loadSound("lon.mp3")


    let l = document.createElement("a-box");
    l.setAttribute("position", {x:0, y:0, z:-2});
    l.setAttribute("width", 1);
    l.setAttribute("height", .2);
    l.setAttribute("depth", 1);
    l.setAttribute("color", "gray");
    this.obj.append(l);  

    let i = document.createElement("a-cylinder");
    i.setAttribute("position", {x:0, y:6, z:-2});
    i.setAttribute("radius", .2);
    i.setAttribute("height", 13);
    i.setAttribute("static-body", "");
    i.setAttribute("color", "brown");
    this.obj.append(i);

    let j = document.createElement("a-torus");
    j.setAttribute("position", {x:0, y:12, z:-1});
    j.setAttribute("rotation", {x:0, y:90, z:0})
    j.setAttribute("arc", 160);
    j.setAttribute("radius", 1);
    j.setAttribute("color", "green");
    j.setAttribute("radius-tubular", .1);
    this.obj.append(j);

    let ok = document.createElement("a-cone");
    ok.setAttribute("position", {x:0, y:12, z:0});
    ok.setAttribute("radius-bottom", .5);
    ok.setAttribute("radius-top", .1);
    ok.setAttribute("height", 1);
    ok.setAttribute("color", "white");
    this.obj.append(ok);

    this.light = document.createElement("a-cone");
    this.light.setAttribute("position", {x:0, y:12, z:0});
    this.light.setAttribute("radius-bottom", .5);
    this.light.setAttribute("radius-top", .1);
    this.light.setAttribute("height", 1);
    this.light.setAttribute("color", "white");
    this.obj.append(this.light);

    let q = document.createElement("a-box");
    q.setAttribute("position", {x:0, y:3, z:-1.8});
    q.setAttribute("width", .1);
    q.setAttribute("height", .1);
    q.setAttribute("depth", .2);
    q.setAttribute("color", "blue");
    q.addEventListener("click", ()=>{
      this.light.setAttribute("position", {x:0, y:9, z:0});
      this.light.setAttribute("color", "yellow");
      this.light.setAttribute("material", "opacity:.5, transparent:true");
      this.light.setAttribute("radius-bottom", 3);
      this.light.setAttribute("radius-top", 0.5);
      this.light.setAttribute("height", 5);
      playSound(lon);
    })
    this.obj.append(q);

    let g = document.createElement("a-box");
    g.setAttribute("position", {x:0, y:3.2, z:-1.8});
    g.setAttribute("width", .1);
    g.setAttribute("height", .1);
    g.setAttribute("depth", .2);
    g.setAttribute("color", "gray");
    g.addEventListener("click", ()=>{
      this.light.setAttribute("position", {x:0, y:12, z:0});
      this.light.setAttribute("color", "white");
      this.light.setAttribute("radius-bottom", .5);
      this.light.setAttribute("radius-top", .1);
      this.light.setAttribute("height", 1);
      this.light.setAttribute("material", "opacity: 1, transparent:false")
      playSound(lon);
    })
    this.obj.append(g);

    this.obj.setAttribute("position", {x:this.x, y:this.y, z:this.z});
    scene.append(this.obj)
  }
  changeRotation(i,j,k){
    this.i = i;
    this.j = j;
    this.k = k;
    this.obj.setAttribute("rotation", {x:this.i, y:this.j, z:this.k});
  }
}      
 